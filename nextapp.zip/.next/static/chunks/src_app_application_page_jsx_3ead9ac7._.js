(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6824eb85._.js",
  "static/chunks/src_app_7d1d9f5c._.js"
],
    source: "dynamic"
});
