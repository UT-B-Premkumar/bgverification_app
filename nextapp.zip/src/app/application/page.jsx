"use client";
import { useForm } from "react-hook-form";
import Layout from "../components/Layout";

export default function NewCaseForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = (data) => {
    console.log("Form Data:", data);
    alert("Form submitted successfully!");
  };

  return (
    <Layout>
      {/* <h2 className="text-2xl font-bold mb-6">Add New Case</h2> */}

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="bg-white p-6 rounded-xl shadow-md max-w-4xl space-y-6"
      >
        {/* Grid container */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Name</label>
            <input
              type="text"
              {...register("name", { required: "Name is required" })}
              className="mt-1 w-full border rounded-lg px-3 py-2 focus:ring focus:ring-blue-200 outline-none"
              placeholder="Enter full name"
            />
            {errors.name && <p className="text-red-500 text-sm">{errors.name.message}</p>}
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <input
              type="email"
              {...register("email", { required: "Email is required" })}
              className="mt-1 w-full border rounded-lg px-3 py-2 focus:ring focus:ring-blue-200 outline-none"
              placeholder="Enter email"
            />
            {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
          </div>

          {/* Aadhaar */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Aadhaar Card</label>
            <input
              type="text"
              {...register("aadhaar", {
                required: "Aadhaar is required",
                pattern: { value: /^[0-9]{12}$/, message: "Enter 12-digit Aadhaar" },
              })}
              className="mt-1 w-full border rounded-lg px-3 py-2 focus:ring focus:ring-blue-200 outline-none"
              placeholder="1234-5678-9012"
            />
            {errors.aadhaar && <p className="text-red-500 text-sm">{errors.aadhaar.message}</p>}
          </div>

          {/* PAN */}
          <div>
            <label className="block text-sm font-medium text-gray-700">PAN Card</label>
            <input
              type="text"
              {...register("pan", {
                required: "PAN is required",
                pattern: { value: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, message: "Invalid PAN format" },
              })}
              className="mt-1 w-full border rounded-lg px-3 py-2 uppercase focus:ring focus:ring-blue-200 outline-none"
              placeholder="ABCDE1234F"
            />
            {errors.pan && <p className="text-red-500 text-sm">{errors.pan.message}</p>}
          </div>

          {/* 10th Marksheet */}
          <div>
            <label className="block text-sm font-medium text-gray-700">10th Marksheet</label>
            <input
              type="file"
              accept=".pdf,.jpg,.png"
              {...register("marks10", { required: "10th marksheet is required" })}
              className="mt-1 w-full border rounded-lg px-3 py-2 focus:ring focus:ring-blue-200 outline-none"
            />
            {errors.marks10 && <p className="text-red-500 text-sm">{errors.marks10.message}</p>}
          </div>

          {/* 12th Marksheet */}
          <div>
            <label className="block text-sm font-medium text-gray-700">12th Marksheet</label>
            <input
              type="file"
              accept=".pdf,.jpg,.png"
              {...register("marks12", { required: "12th marksheet is required" })}
              className="mt-1 w-full border rounded-lg px-3 py-2 focus:ring focus:ring-blue-200 outline-none"
            />
            {errors.marks12 && <p className="text-red-500 text-sm">{errors.marks12.message}</p>}
          </div>

          {/* College Certificate */}
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700">College Certificate (PDF)</label>
            <input
              type="file"
              accept=".pdf"
              {...register("college", { required: "College certificate is required" })}
              className="mt-1 w-full border rounded-lg px-3 py-2 focus:ring focus:ring-blue-200 outline-none"
            />
            {errors.college && <p className="text-red-500 text-sm">{errors.college.message}</p>}
          </div>
        </div>

        {/* Submit */}
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition"
        >
          Submit
        </button>
      </form>
    </Layout>
  );
}
