import Layout from "../components/Layout";
import { Eye } from "lucide-react";

export default function Cases() {
  // Example cases data
  const cases = [
    {
      id: 1,
      name: "Ravi Kumar",
      aadhaar: "1234-5678-9012",
      reason: "Theft",
      punishment: "2 years",
      status: "Pending",
    },
    {
      id: 2,
      name: "Suresh Singh",
      aadhaar: "9876-5432-1098",
      reason: "Fraud",
      punishment: "5 years",
      status: "Closed",
    },
    {
      id: 3,
      name: "Amit Sharma",
      aadhaar: "1111-2222-3333",
      reason: "Smuggling",
      punishment: "10 years",
      status: "Pending",
    },
  ];

  return (
    <Layout>
      <h2 className="text-2xl font-bold mb-4">Cases</h2>

      <div className="bg-white rounded-xl shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Cases List</h3>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-100 text-left">
                <th className="p-3 text-sm font-medium text-gray-600">Name</th>
                <th className="p-3 text-sm font-medium text-gray-600">Aadhaar Card</th>
                <th className="p-3 text-sm font-medium text-gray-600">Reason</th>
                <th className="p-3 text-sm font-medium text-gray-600">Punishment</th>
                <th className="p-3 text-sm font-medium text-gray-600">Status</th>
                <th className="p-3 text-sm font-medium text-gray-600">Action</th>
              </tr>
            </thead>
            <tbody>
              {cases.map((c) => (
                <tr key={c.id} className="border-b hover:bg-gray-50">
                  <td className="p-3 text-gray-700">{c.name}</td>
                  <td className="p-3 text-gray-700">{c.aadhaar}</td>
                  <td className="p-3 text-gray-700">{c.reason}</td>
                  <td className="p-3 text-gray-700">{c.punishment}</td>
                  <td className="p-3">
                    <span
                      className={`px-3 py-1 text-xs font-medium rounded-full ${
                        c.status === "Pending"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-green-100 text-green-700"
                      }`}
                    >
                      {c.status}
                    </span>
                  </td>
                  <td className="p-3">
                    <button className="text-blue-600 hover:text-blue-800">
                      <Eye className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
}
